<?php
// On prolonge la session  
session_start();
?>
      <nav  id="na" class="navbar navbar-default navbar-fixed-top navbar-custom">
        <div id="menu">
        <ul id="navigation">
          <li><a href="index_english.php" title="HomePage">Home</a></li>
          <li><a href="visualiser_liste_english.php" title="See the list of advertisments"> List </a></li>
          <li><a href="visualiser_liste_ajax_english.php" title="Add advertisments"> Add </a></li>

          <li><a href="visualiser_liste_ajax_english.php" title="Search advertisments"> Search </a></li>
          <li><a href="index_english.php" title="English"> EN </a></li>
          <li><a href="index.php" title="Français"> FR </a></li>
        <?php
            // On teste si la variable de session existe et contient une valeur
            if(!empty($_SESSION['login']))
            {
                echo '<div style="align:center">
                <p style="color:#242830">bienvenue ',$_SESSION['login'] ,'<button id="deconnecte" style="color:black;" type="submit"   >log out</button></p> </div>' ;
            }
            else{
              echo '
                  <form id="connect" method="post">
                  <input style="color:black;" type="email" name ="adressemail" placeholder=" e-mail ">
                  <input style="color:black;" type="password" name="motdepasse" placeholder="password">
                  <input  type="submit" style="color:black;" value="log in"></form>';
                  echo'<label id="ereur" style="color:red;margin-left:1250px;"> </label>';
            }
          ?>
           </ul>
        </div>     
      </nav>



