<footer>
  <div class="footer-below">
   <hr class="star-light">
   <span class="italic">Copyright &copy; Fagaye Sarr GUEYE & Fatou DOUKOURE </span>
   <p style="font-style:italic; font-size: 14px;">
   	<SCRIPT>
   		document.write("Last update : " + document.lastModified)
    </SCRIPT>
   </p>
  </div>
</footer>

