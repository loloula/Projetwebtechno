<?php
include("bdd.php");
creationTable();
insertionDonneesExemple();
 ?>
