<?php
// On prolonge la session
// session_start();
?>
      <nav  id="na" class="navbar navbar-default navbar-fixed-top navbar-custom">
        <div id="menu">
        <ul id="navigation">
          <li><a href="index.php" title="Page d'accueil">Accueil</a></li>
          <li><a href="visualiser_liste.php" title="Visualiser la liste d'annonces">Liste </a></li>
          <li><a href="visualiser_liste_ajax.php" title="Ajouter des annonces"> Ajout </a></li>
          <li><a href="visualiser_liste_ajax.php" title="Rechercher des annonces"> Recherche </a></li>

          <li><a href="index_english.php" title="English"> EN </a></li>
          <li><a href="index.php" title="Français"> FR </a></li>


        </div>
        </ul>
      <div id="connexion">
        <?php

            // On teste si la variable de session existe et contient une valeur
            if(!empty($_SESSION['login']))
            {
                echo '<p style="margin-left:1070px;color:white;width:300px">bienvenue ',$_SESSION['login'],'</p><button id="deconnecte" style="margin-left:1350px;margin-top:-50px;color:white;" type="submit"  class="btn btn-primary mb-2" >deconexion</button>' ;
            }
            else{
              echo '<form id="connect" method="post" style="margin-left:880px;">
                  <input style="color:black;" type="email" name ="adressemail" placeholder=" e-mail ">
                  <input style="color:black;" type="password" name="motdepasse" placeholder="mot de passe">
                  <input  type="submit" style="color:black;" value="connexion"></form>';
                  echo'<label id="ereur" style="color:red;margin-left:1250px;"> </label>';
            }
          ?>
        </div>     
      </nav>


