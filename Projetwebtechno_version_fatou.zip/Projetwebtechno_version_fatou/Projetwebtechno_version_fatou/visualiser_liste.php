<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title> F'Cat - Liste Annonces </title>
    <script type="text/javascript" src="static/js/annonce.js"></script>
    <script type="text/javascript" src="static/js/annonce1.js"></script>
    <script type="text/javascript" src="static/js/annonce2.js"></script>
    
    <link rel="stylesheet" type="text/css" href="static/css/style.css"></link>
    <link rel="stylesheet" href="static/css/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="static/css/freelancer-theme.min.css">

    <script src="https://use.fontawesome.com/470b91f216.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css">

  </head>
  <style media="screen">
    img{
      width: 200px;
    }
  </style>  
  <body>
     <div>
      <!-- inclure l'entete de la page -->
      <?php include("entete.php"); ?>
      <main id="liste">
      <?php  
      //importation de la base de donnee
      include("bdd.php");
                                
      //connexion à la base de donnee
      $pdo=connexion();

      //requete de selection
      $requeteSQL = "SELECT * FROM annonces";
      
      //exécution de la requete
      $rst = $pdo->query($requeteSQL);
                      
      // récupération des résultats
      $annonces = $rst->fetchAll(PDO::FETCH_ASSOC);

     //parcourir la table annonce et affiché chaque objet dans un div
      foreach ($annonces as $a) {
                      echo '<div> <h3>',$a['titre'],'</h3>
                      <h4>', "Description: ", $a['description'], '</h4>
                      <h4>', "Pseudo: ", $a['pseudo'], '</h4>
                      <h4>', "Latitude: ", $a['rdv_lat'], '</h4>
                      <h4>', "Longitude: ", $a['rdv_lon'], '</h4>
                      <h4> Photo: <img src="img/',$a['photo'],'"></h4>
                      <h4>', "Date: ", $a['date'], '</h4>
                      <h4>', "Prix: ", $a['prix'], " €" ,'</h4></div>';                   
                      }
                       ?>
              
      </main>
 
      <!-- inclure le pied de la page -->
      <?php include("pied.php"); ?>
     </div>
  </body>
</html>
