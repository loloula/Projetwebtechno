<?php
include("bdauthentif.php");
creationTable();
insertionDonneesExemple();


 ?>
