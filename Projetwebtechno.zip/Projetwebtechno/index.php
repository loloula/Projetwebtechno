

<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>mes annonces</title>
    <link rel="stylesheet" type="text/css" href="static/css/style.css"></link>
    <script type="text/javascript" src="static/js/annonce1.js"></script>
    <script type="text/javascript" src="static/js/annonce2.js"></script>
    <link rel="stylesheet" href="static/css/bootstrap/bootstrap.min.css">

    <!-- Theme CSS -->
    <link rel="stylesheet" href="static/css/freelancer-theme.min.css">

    <!-- Custom CSS -->
    <script src="https://use.fontawesome.com/470b91f216.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css">
  </head>
  <body>
<?php include("entete.php"); ?>

        <main id="mai" style="margin-top:100px">
          <article class="">


                <aside id="art1">
                <p id="pp">hello<br>bienvenue <br>
                nous vous proposons plusieurs univers d'annonces</p>
                </aside>
                <aside id="art2">

                </aside>

                </article>



        </main>
        <footer>
          <div class="footer-below">

                          <hr class="star-light">
                          <span class="italic" style="margin-left:600px">Copyright &copy; Fagaye sarr GUEYE && Fatou DOUKOURE </span>
                          <p style="font-style:italic; font-size: 14px;margin-left:650px">
                              <SCRIPT >

                                          document.write("derniére mise à jour : " + document.lastModified)
                              </SCRIPT>
                        </p>

          </div>
        </footer>

  </body>
</html>
